//
//  CoirTableViewCell.swift
//  Inventory
//
//  Created by Atharv Sathe on 18/08/19.
//  Copyright © 2019 Atharv Sathe. All rights reserved.
//

import UIKit

class CoirTableViewCell: UITableViewCell {
    @IBOutlet weak var coirView: CoirView!
    
}
